$(function() {
  'use strict';

  $('#myDropify').dropify();
  $('.myDropify').dropify();
});
